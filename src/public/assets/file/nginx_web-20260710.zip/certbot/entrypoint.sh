set -eu

sleep_seconds="${RENEW_INTERVAL_SECONDS:-43200}"

while true; do
  certbot renew \
    --webroot -w /var/www/certbot \
    --deploy-hook 'kill -HUP 1' \
    --quiet

  sleep "$sleep_seconds"
done

